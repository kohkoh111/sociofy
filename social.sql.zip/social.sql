-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 14, 2021 at 07:23 AM
-- Server version: 5.7.30
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `social`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_body` text NOT NULL,
  `posted_by` varchar(60) NOT NULL,
  `posted_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `removed` varchar(3) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_body`, `posted_by`, `posted_to`, `date_added`, `removed`, `post_id`) VALUES
(1, 'Hello', 'koki_takata', 'koki_takata', '2021-03-06 01:37:07', 'no', 11),
(2, 'hi there', 'koki_takata', 'koki_takata', '2021-03-06 22:11:00', 'no', 10),
(3, 'hi there\r\n', 'koki_takata', 'koki_takata', '2021-03-06 22:16:55', 'no', 11),
(4, '', 'koki_takata', 'koki_takata', '2021-03-07 10:47:43', 'no', 11),
(5, '', 'koki_takata', 'koki_takata', '2021-03-07 10:47:44', 'no', 11),
(6, 'good night\r\n', 'koki_takata', 'koki_takata', '2021-03-10 23:05:47', 'no', 11),
(7, 'Nice to see you \r\n', 'koki_takata', 'jim_thompson', '2021-03-11 21:39:25', 'no', 20),
(8, 'good', 'jim_thompson', 'jim_thompson', '2021-03-13 20:36:20', 'no', 20),
(9, 'good night', 'jim_thompson', 'jim_thompson', '2021-03-13 22:45:30', 'no', 21);

-- --------------------------------------------------------

--
-- Table structure for table `friend_requests`
--

CREATE TABLE `friend_requests` (
  `id` int(11) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `user_from` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `friend_requests`
--

INSERT INTO `friend_requests` (`id`, `user_to`, `user_from`) VALUES
(4, 'test1_user', 'koki_takata');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `post_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `username`, `post_id`) VALUES
(7, 'koki_takata', 10),
(8, 'koki_takata', 11),
(9, 'koki_takata', 8),
(10, 'test_user', 8),
(11, 'koki_takata', 9),
(12, 'koki_takata', 15),
(15, 'jim_thompson', 21);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `user_from` varchar(60) NOT NULL,
  `body` text NOT NULL,
  `date` datetime NOT NULL,
  `opened` varchar(3) NOT NULL,
  `viewed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_to`, `user_from`, `body`, `date`, `opened`, `viewed`, `deleted`) VALUES
(1, 'koki_takata', 'jim_thompson', 'hi there', '2021-03-14 00:06:55', 'yes', 'no', 'no'),
(2, 'koki_takata', 'jim_thompson', 'how are y', '2021-03-14 00:09:34', 'yes', 'no', 'no'),
(3, 'koki_takata', 'jim_thompson', 'good night\r\n', '2021-03-14 00:09:39', 'yes', 'no', 'no'),
(4, 'koki_takata', 'jim_thompson', 'dog', '2021-03-14 00:09:43', 'yes', 'no', 'no'),
(5, 'jim_thompson', 'koki_takata', 'great', '2021-03-14 00:10:16', 'yes', 'no', 'no'),
(6, 'jim_thompson', 'koki_takata', 'have a good day', '2021-03-14 00:10:26', 'yes', 'no', 'no'),
(7, 'koki_takata', 'jim_thompson', 'see you ', '2021-03-14 02:05:09', 'yes', 'no', 'no'),
(8, 'koki_takata', 'jim_thompson', 'btw\r\n', '2021-03-14 02:05:14', 'yes', 'no', 'no'),
(9, 'koki_takata', 'jim_thompson', 'doggy', '2021-03-14 02:05:23', 'yes', 'no', 'no'),
(10, 'koki_takata', 'jim_thompson', 'doggy', '2021-03-14 02:11:41', 'yes', 'no', 'no'),
(11, 'koki_takata', 'jim_thompson', 'good night', '2021-03-14 02:11:49', 'yes', 'no', 'no'),
(12, 'jim_thompson', 'koki_takata', 'good night too\r\n', '2021-03-14 02:12:43', 'no', 'no', 'no'),
(13, 'test_user', 'koki_takata', 'hi there\r\n', '2021-03-14 10:50:00', 'no', 'no', 'no'),
(14, 'test_user', 'koki_takata', 'hi there\r\n', '2021-03-14 10:50:08', 'no', 'no', 'no'),
(16, 'jim_thompson', 'koki_takata', 'great', '2021-03-14 15:48:30', 'no', 'no', 'no'),
(17, 'jim_thompson', 'koki_takata', 'great', '2021-03-14 15:48:52', 'no', 'no', 'no'),
(18, 'jim_thompson', 'koki_takata', 'later', '2021-03-14 15:49:05', 'no', 'no', 'no'),
(19, 'jim_thompson', 'koki_takata', 'see u', '2021-03-14 15:54:28', 'no', 'no', 'no'),
(20, 'jim_thompson', 'koki_takata', 'u', '2021-03-14 15:55:13', 'no', 'no', 'no'),
(21, 'jim_thompson', 'koki_takata', 'nn', '2021-03-14 15:55:31', 'no', 'no', 'no'),
(22, 'jim_thompson', 'koki_takata', 'hello', '2021-03-14 15:56:30', 'no', 'no', 'no'),
(23, 'jim_thompson', 'koki_takata', 'hello', '2021-03-14 15:57:00', 'no', 'no', 'no'),
(24, 'jim_thompson', 'koki_takata', 'long time no see', '2021-03-14 15:58:10', 'no', 'no', 'no'),
(25, 'jim_thompson', 'koki_takata', 'how are you\r\n', '2021-03-14 15:58:50', 'no', 'no', 'no'),
(26, 'jim_thompson', 'koki_takata', 'great', '2021-03-14 16:01:20', 'no', 'no', 'no'),
(27, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:01:49', 'no', 'no', 'no'),
(28, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:05:55', 'no', 'no', 'no'),
(29, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:06:23', 'no', 'no', 'no'),
(30, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:06:31', 'no', 'no', 'no'),
(31, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:12:44', 'no', 'no', 'no'),
(32, 'jim_thompson', 'koki_takata', 'cat', '2021-03-14 16:12:54', 'no', 'no', 'no'),
(33, 'jim_thompson', 'koki_takata', 'cat', '2021-03-14 16:13:05', 'no', 'no', 'no'),
(34, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:13:14', 'no', 'no', 'no'),
(35, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:16:39', 'no', 'no', 'no'),
(36, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:17:20', 'no', 'no', 'no'),
(37, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:17:25', 'no', 'no', 'no'),
(38, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:18:06', 'no', 'no', 'no'),
(39, 'jim_thompson', 'koki_takata', 'dog', '2021-03-14 16:21:49', 'no', 'no', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `added_by` varchar(60) NOT NULL,
  `user_to` varchar(60) NOT NULL,
  `date_added` datetime NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `deleted` varchar(3) NOT NULL,
  `likes` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `body`, `added_by`, `user_to`, `date_added`, `user_closed`, `deleted`, `likes`) VALUES
(1, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 14:09:02', 'no', 'no', 0),
(2, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 18:05:59', 'no', 'no', 0),
(3, 'hello\r\n', 'koki_takata', 'none', '2021-02-21 18:06:03', 'no', 'no', 0),
(4, 'koki', 'koki_takata', 'none', '2021-02-21 18:06:29', 'no', 'no', 0),
(5, 'how are you', 'koki_takata', 'none', '2021-02-21 18:06:35', 'no', 'no', 0),
(6, 'how are you', 'koki_takata', 'none', '2021-02-21 18:07:05', 'no', 'no', 0),
(7, 'how are you', 'koki_takata', 'none', '2021-02-21 18:07:29', 'no', 'no', 0),
(8, 'Hello world', 'test_user', 'none', '2021-02-22 07:20:24', 'no', 'no', 2),
(9, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:30:27', 'no', 'no', 1),
(10, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:33:20', 'no', 'yes', 1),
(11, 'Hello\r\n', 'koki_takata', 'none', '2021-03-06 00:33:29', 'no', 'yes', 1),
(12, 'test', 'jim_thompson', 'koki_takata', '2021-03-11 00:28:01', 'no', 'no', 0),
(13, 'post', 'koki_takata', 'koki_takata', '2021-03-11 00:29:41', 'no', 'no', 0),
(14, 'post', 'koki_takata', 'koki_takata', '2021-03-11 00:30:59', 'no', 'no', 0),
(15, 'kkkk', 'koki_takata', 'none', '2021-03-11 00:31:07', 'no', 'no', 1),
(16, 'kkkk', 'koki_takata', 'none', '2021-03-11 00:32:14', 'no', 'yes', 0),
(17, 'test post\r\n', 'koki_takata', 'koki_takata', '2021-03-11 00:32:31', 'no', 'no', 0),
(18, 'this is koki', 'koki_takata', 'none', '2021-03-11 00:35:11', 'no', 'yes', 0),
(19, 'test post', 'koki_takata', 'none', '2021-03-11 00:38:26', 'no', 'yes', 0),
(20, 'hi there\r\n', 'jim_thompson', 'koki_takata', '2021-03-11 21:38:25', 'no', 'no', 0),
(21, 'feel like sleeping', 'jim_thompson', 'none', '2021-03-13 20:35:31', 'no', 'no', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `signup_date` datetime NOT NULL,
  `profile_pic` varchar(255) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `num_likes` int(11) NOT NULL,
  `user_closed` varchar(3) NOT NULL,
  `friend_array` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `username`, `email`, `password`, `signup_date`, `profile_pic`, `num_posts`, `num_likes`, `user_closed`, `friend_array`) VALUES
(1, 'Koki', 'Takata', 'koki_takata', 'Koh724@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-21 00:00:00', 'assets/images/profile_pics/defaults/head_emerald.png', 14, 6, 'no', ',test_user1,test_user,jim_thompson,'),
(4, 'Test', 'User', 'test_user', 'Test@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-22 00:00:00', 'assets/images/profile_pics/defaults/head_emerald.png', 1, 2, 'no', ',koki_takata,jim_thompson,'),
(5, 'Test', 'User1', 'test_user1', 'Test1@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-02-22 00:00:00', 'assets/images/profile_pics/defaults/head_deep_blue.png', 0, 0, 'no', ',koki_takata,jim_thompson,'),
(6, 'Jim', 'Thompson', 'jim_thompson', 'Jim@mail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2021-03-11 00:00:00', 'assets/images/profile_pics/jim_thompsonab840b663e73309d14c55029dd563e2dn.jpeg', 2, 1, 'no', ',koki_takata,test_user1,');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friend_requests`
--
ALTER TABLE `friend_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `friend_requests`
--
ALTER TABLE `friend_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
